import express from 'express';
import mongoose from 'mongoose';
import dotenv from 'dotenv';
import cors from 'cors';

dotenv.config();
const app = express();
app.use(cors());
app.use(express.json());

// Routes
import rideRoutes from './models/Ride.js';
app.use('/api/rides', rideRoutes);

// DB + Server
mongoose.connect(process.env.MONGO_URI).then(() => {
  app.listen(5000, () => console.log("Server started on port 5000"));
});
