import mongoose from 'mongoose';

const rideSchema = new mongoose.Schema({
  from: String,
  to: String,
  date: Date,
  availableSeats: Number,
  driverName: String
});

export default mongoose.model('Ride', rideSchema);
