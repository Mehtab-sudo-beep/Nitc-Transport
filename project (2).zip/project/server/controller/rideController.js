import Ride from '../models/Ride.js';

export const getRides = async (req, res) => {
  const rides = await Ride.find();
  res.json(rides);
};

export const createRide = async (req, res) => {
  const newRide = new Ride(req.body);
  await newRide.save();
  res.status(201).json(newRide);
};
