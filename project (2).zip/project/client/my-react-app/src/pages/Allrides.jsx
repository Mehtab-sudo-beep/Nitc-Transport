import { useEffect, useState } from "react";
import { getAllRides } from "../services/rideService";

export default function AllRides() {
  const [rides, setRides] = useState([]);

  useEffect(() => {
    getAllRides().then(data => setRides(data));
  }, []);

  return (
    <div className="p-4">
      {rides.map((ride, idx) => (
        <div key={idx} className="bg-white p-4 shadow mb-3 rounded">
          <p><strong>From:</strong> {ride.from}</p>
          <p><strong>To:</strong> {ride.to}</p>
          <p><strong>Driver:</strong> {ride.driverName}</p>
        </div>
      ))}
    </div>
  );
}
